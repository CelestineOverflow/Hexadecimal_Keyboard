//===========================================================
// Example Program for the TIVA TM4C1294XL Evaluation Board
// With this file you can print text to the console of the
// Code Composer Studio.
//==========================================================
// ! IMPORTANT !
// This program runs endless. Stop with the "Red Square Button"
// in Debug Mode (Terminate = CTRL + F2)
//==========================================================
// Include the Header File for controller tm4c1294ncpdt
#include "inc/tm4c1294ncpdt.h"
#include <stdint.h>
#include <stdio.h>
#include "lib\basics.h"
// prototypes
void setup(void);
void loop1(void);
char getKey();

int steps = 1000000;

void wait(unsigned long steps)
{
    unsigned long j;
    for (j = 0; j < steps; j++)
        ;
}

void main(void)
{
    setup();
    loop1();
}

void setup()
{
    printf("Starting Keyboard\n");
    SYSCTL_RCGCGPIO_R |= SYSCTL_RCGCGPIO_R3; // clock enable
    while ((SYSCTL_RCGCGPIO_R & SYSCTL_RCGCGPIO_R3) == 0)
    {
    };
    GPIO_PORTD_AHB_DEN_R |= 0xFF; // enable digital I/O
    GPIO_PORTD_AHB_DIR_R |= 0xFF; // set PORTM pins 0-3 as input and 4-7 as output
}
#include <stdint.h>
void loop1()
{
    uint16_t x = 0;
    while (true)
    {

        if (GPIO_PORTD_AHB_DATA_R == 0x00)
        {
            GPIO_PORTD_AHB_DATA_R = 0xFF;
        }
        else
        {
            GPIO_PORTD_AHB_DATA_R = 0x00;
        }
    }
    for (x = 0; x < 10; x++)
        ;
}

void loop()
{

    while (true)
    {
        // wait(steps);
        if (GPIO_PORTD_AHB_DATA_R == 0x00)
        {
            GPIO_PORTD_AHB_DATA_R = 0xFF;
            unsigned long j;
            for (j = 0; j < steps; j++)
                ;
        }
        else
        {
            GPIO_PORTD_AHB_DATA_R = 0x00;
            // printf("off\n");
            unsigned long j;
            for (j = 0; j < steps; j++)
            {
            }
        }
    }
}

char keyboard_output[16] = {'1', '2', '3', 'F', '4', '5', '6', 'E', '7', '8', '9', 'D', 'A', '0', 'B', 'C'};

char getKey()
{
    char key = '\0';
    int keys = 0;
    int i;
    for (i = 4; i < 8; i++)
    {
        GPIO_PORTM_DATA_R |= 0xF0; // SET PORTM pins 4-7 as HIGH
        setPin(GPIO_PORTM_DATA_R, i, false);
        int j;
        for (j = 0; j < 4; j++)
        {
            delay(1000);
            if (!checkPin(j, GPIO_PORTM_DATA_R)) // Active low
            {
                key = keyboard_output[j + i - 4]; // I hope this makes sense
                keys++;
            }
        }

        setPin(GPIO_PORTM_DATA_R, i, true);
    }
    if (keys == 1 || keys == 0)
    {
        return key;
    }
    else
    {
        printf("Error: %d keys pressed\n", keys);
        return '\0';
    }
}
