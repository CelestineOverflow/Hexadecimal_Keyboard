# Hexadecimal_Keyboard
 Lab_1
The damm thing runs obscure c99 or something like that so it doesnt support def inside the for loops
